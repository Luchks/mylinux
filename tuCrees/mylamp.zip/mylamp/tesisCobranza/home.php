<?php
    session_start();
    if(isset($_SESSION['id']) && isset($_SESSION['user_name'])){

?>
<!DOCTYPE html>
<html>
<head>
    <title>HOME</title>
    <link rel="stylesheet" type="text/css" href="../tesisStyle/style.css">
</head>
<body>
    <h1>Hello , you lost a lot of time, <?php echo $_SESSION['name']; ?></h1>
    <br>
    <br>
    <a href="../tesisLogin/logout.php">Cerrar Sesion</a>
    <br>
    <h2><a href="../tesisCobranza/tableJsCssHtml/index.html">TABLA DE MUESTRA</a></h2>
</body>
</html>
<?php
    }else{
        header("Location: ../tesis/index.php");
        exit();
    }
?>