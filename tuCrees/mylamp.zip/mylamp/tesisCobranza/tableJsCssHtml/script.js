


const search = document.querySelector(".input-group input"),
table_rows = document.querySelectorAll("tbody tr"),
table_headings = document.querySelectorAll("thead th");

//01 ...searching for specific data of html table
search.addEventListener("input", searchTable);

function searchTable() {
	table_rows.forEach((row, i) => {
		let table_data = row.textContent.toLowerCase(),
		search_data = search.value.toLowerCase();

		row.classList.toggle("hide", table_data.indexOf(search_data)<0);
		row.style.setProperty("--delay",i/25+"s");
	}) 

	document.querySelector("tbody tr:not(.hide)").forEach((visible_row, i) => {
		visible_row.style.background = (i % 2 === 0) ? "transparent" : "#000000b";
	});
} 
//02 ...sorting table || ordering data for html table
table_headings.forEach((head,i)=>{
	let sort_arc = true;
	head.onclick = ()=>{
		table_headings.forEach(head =>head.classList.remove("active"));
		head.classList.add("active");

		document.querySelectorAll("td").forEach(td => td.classList.remove("active"))
		table_rows.forEach(row => { row.querySelectorAll("td")[i].classList.add("active") })

		head.classList.toggle("asc",sort_arc);
		sort_arc = head.classList.contains("asc") ? false : true;

		sortTable(i,sort_arc);
	}
})

function sortTable(column,sort_arc) {
	[...table_rows].sort((a,b)=>{
		let first_row = a.querySelectorAll("td")[column].textContent.toLowerCase(),
				second_row = b.querySelectorAll("td")[column].textContent.toLowerCase();

	return sort_arc ? (first_row < second_row ? 1 : -1 ) : (first_row < second_row ? -1 : 1); 

})
	.map(sorted_row => document.querySelector("tbody").appendChild(sorted_row))
}
//03 ...converting html table to PDF

const pdf_btn = document.querySelector("#toPDF");
const customers_table = document.querySelector("#customers_table");

const toPDF = function (customers_table) {
	const html_code = `
	<link rel="stylesheet" href="style.css">
	<main class="table">${customers_table.innerHTML}</main>
	`;

	const new_window = window.open();
	new_window.document.write(html_code);


	setTimeout(() => { 
		new_window.print();
		new_window.close();
	}, 200);
}

pdf_btn.onclick = () => {
	toPDF(customers_table);
}

//04 ...converting html table to JSON
const json_btn = document.querySelector("#toJSON");
 
const toJSON = function (table) {
	let table_data = [],
	t_head = [],
	t_headings = table.querySelectorAll("thead th");
	t_rows = table.querySelectorAll("tbody tr");
	for (let t_heading of t_headings) {
		let actual_head= t_heading.textContent.trim();
		t_head.push(actual_head.splice(0,actual_head.length-1).trim(" ").toLowerCase());
	}
	console.log(t_head);
}
json_btn.onclick = () => {
	toJSON(customers_table);
}	

