<?php 
    phpinfo();
    echo "Hello world";
?>
