<?php
include 'User.php';
interface UserDAO
{
    public function insert(User $user);
    public function update(User $user);
    public function delete(User $user);
    public function select(User $user);
    public function findId(User $user);
    public function selectAll();
}

?>
