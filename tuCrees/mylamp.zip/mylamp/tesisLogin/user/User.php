<?php

class User {
    private $accion;
    private $id;
    private $user_name;
    private $password;
    private $name;
    private $flagActive;
    public function __construct() {
        $this->accion = "";
        $this->id = 0;
        $this->user_name = "";
        $this->password = "";
        $this->name = "";
        $this->flagActive = "";
    }

    public function __construct($accion, $id, $user_name, $password, $name, $flagActive) {
        $this->accion = $accion;
        $this->id = $id;
        $this->user_name = $user_name;
        $this->password = $password;
        $this->name = $name;
        $this->flagActive = $flagActive;
    }
    public function getAccion() {
        return $this->accion;
    }
    public function setAccion($accion) {
        $this->accion = $accion;
    }

    public function getId() {
        return $this->id;
    }
    public function setId($id) {
        $this->id = $id;
    }

    public function getUser_name() {
        return $this->user_name;
    }

    public function setUser_name($user_name) {
        $this->user_name = $user_name;
    }

    public function getPassword() {
        return $this->password;
    }

    public function setPassword($password) {
        $this->password = $password;
    }

    public function getName() {
        return $this->name;
    }

    public function setName($name) {
        $this->name = $name;
    }

    public function getFlagActive() {
        return $this->flagActive;
    }

    public function setFlagActive($flagActive) {
        $this->flagActive = $flagActive;
    }

}
?>
