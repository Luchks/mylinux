<?php
include 'User.php';
include 'UserDAO.php';

class UserDAOImpl implements UserDAO {
    private $listUsers = array();
    public function __contructor() {
        for ($i=0; $i < 10; $i++) {
            array_push($this->listUsers, new User(1,$i, "User $i", "User $i", "User $i","1"));
        }
    }
    public function insert(User $user){
        array_push($this->listUsers, $user);
    }
    public function update(User $user){
      if(count($this->listUsers) > 0){
          for ($i=0; $i < count($this->listUsers); $i++) { 
              if ($user->getId() == $this->listUsers[$i]->getId()) {
                  $this->listUsers[$i] = $user;
              }
          }
      }  
    }
    public function delete(User $user){
        if(count($this->listUsers) > 0){
            for ($i=0; $i < count($this->listUsers); $i++) { 
                if ($user->getId() == $this->listUsers[$i]->getId()) {
                    unset($this->listUsers[$i]);
                }
            }
        }
    }
    public function select(User $user){
        for ($i=0; $i < count($this->listUsers); $i++) {
            if ($user->getId() == $this->listUsers[$i]->getId()) {
                return $this->listUsers[$i];
            }
        }
    }
    public function findId(User $user){
        for ($i=0; $i < count($this->listUsers); $i++) { 
            if ($user->getId() == $this->listUsers[$i]->getId()) {
                return $this->listUsers[$i];
            }
        }
    }
    public function selectAll(){
        return $this->listUsers;
    }
    /*
     * falta implementar el login
     * falta implementar el orm
     * */

}
?>
