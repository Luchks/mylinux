<?php
    session_start();
    include "../tesisOrm/db_conn.php";
    if(isset($_POST['uname']) && isset($_POST['password'])){
        function validate($data){
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
        $uname = validate($_POST['uname']);
        $password= validate($_POST['password']);

        if(empty($uname)){
            header("Location: ../tesis/index.php?error=Se requiere el nombre de usuario");
            exit();
        }else if(empty($password)){
            header("Location: ../tesis/index.php?error=Se requiere la contraseña");
            exit();
        }else {
            $password = md5($password);

            $sql = "call sp_users_sl('$uname','$password')"; 
            $result = mysqli_query($conn,$sql);
            if(mysqli_num_rows($result)===1){
                $row = mysqli_fetch_assoc($result);
                if($row['user_name']===$uname && $row['password']===$password){
                    $_SESSION['user_name'] = $row['user_name'];
                    $_SESSION['name'] = $row['name'];
                    $_SESSION['id'] = $row['id'];
                    header("Location: ../tesisCobranza/tableJsCssHtml/index.html");
                    exit();
                }
                else{
                    header("Location: ../tesis/index.php?error=Usuario o contraseña incorrectos");
                    exit();
                }

            }else{
                header("Location: ../tesis/index.php?error=Usuario o contraseña incorrectos"); 
                exit();
            }
        }
    }else{
        header("Location: ../tesis/index.php");
        exit();
    }