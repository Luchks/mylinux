<?php
    class singleton{
        private static $instance = null;
        private $conn;
        private $sname="cp.vive.pe";
        private $unmae="reservac";
        private $password="*GF4Xwzef9dkiKgE";
        private $db_name="reservac_testdb";
        private function __construct(){
            $this->conn = mysqli_connect($this->sname, $this->unmae,$this->password,$this->db_name);
        }
        public static function getInstance():singleton{
            if(self::$instance==null){
                self::$instance = new singleton();
            }
            return self::$instance;
        }
        public function getConnection(){
            return $this->conn;
        }
    }

    $conn = singleton::getInstance()->getConnection();

    if(!$conn){
        echo "Connection failed!";
    }