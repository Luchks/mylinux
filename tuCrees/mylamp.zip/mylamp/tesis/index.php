<!DOCTYPE html>
<html>
<head>
    <title>Inicio de Sesión</title>
    <link rel="stylesheet" type="text/css" href="../tesisStyle/style.css">
</head>
<body>
    <form action="../tesisLogin/login.php" method="post"> 
        <h2>Inicio de Sesión</h2>
        <?php if(isset($_GET['error'])){ ?>
            <p class="error"><?php echo $_GET['error']; ?></p>
        <?php } ?>
        <label >Nombre de Usuario </label>
        <input type="text" name="uname" placeholder="User Name"><br>

        <label>Contraseña</label>
        <input type="password" name="password" placeholder="Password"><br>

        <button type="submit">Iniciar Sesión</button>

        <a href="../tesisLogin/signup.php" class="ca">Nuevo Usuario</a>
    </form>
</body>
</html>
